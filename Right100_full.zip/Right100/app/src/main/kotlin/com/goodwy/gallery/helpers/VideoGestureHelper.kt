package com.goodwy.gallery.helpers

import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import kotlin.math.abs

data class VideoGestureCallbacks(
    val isPlaying: () -> Boolean,
    val getCurrentSpeed: () -> Float,
    val setPlaybackSpeed: (Float) -> Unit,
    val showPill: () -> Unit,
    val hidePill: () -> Unit,
    val performHaptic: () -> Unit,
    val disallowParentIntercept: () -> Unit
)

class VideoGestureHelper(
    private val touchSlop: Int,
    private val callbacks: VideoGestureCallbacks
) {
    companion object {
        private const val TOUCH_HOLD_DURATION_MS = 500L
        private const val TOUCH_HOLD_SPEED_MULTIPLIER = 2.0f
    }

    private val handler = Handler(Looper.getMainLooper())

    private var initialX = 0f
    private var initialY = 0f
    private var originalSpeed = 1f
    internal var isLongPressActive = false
    private var wasLongPressHandled = false

    private val touchHoldRunnable = Runnable {
        if (callbacks.isPlaying()) {
            callbacks.disallowParentIntercept()
            isLongPressActive = true
            originalSpeed = callbacks.getCurrentSpeed()
            callbacks.performHaptic()
            callbacks.setPlaybackSpeed(TOUCH_HOLD_SPEED_MULTIPLIER)
            callbacks.showPill()
        }
    }

    fun onTouchEvent(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (callbacks.isPlaying() && event.pointerCount == 1) {
                    initialX = event.x
                    initialY = event.y
                    handler.postDelayed(touchHoldRunnable, TOUCH_HOLD_DURATION_MS)
                }
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = abs(event.x - initialX)
                val dy = abs(event.y - initialY)
                if (!isLongPressActive && (dx > touchSlop || dy > touchSlop)) {
                    handler.removeCallbacks(touchHoldRunnable)
                }
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (!isLongPressActive) {
                    handler.removeCallbacks(touchHoldRunnable)
                }
            }

            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(touchHoldRunnable)
                stop()
            }
        }
    }

    fun wasLongPressHandled() = wasLongPressHandled

    fun updateLongPressHandled() {
        wasLongPressHandled = false
    }

    fun stop() {
        if (isLongPressActive) {
            wasLongPressHandled = true
            callbacks.setPlaybackSpeed(originalSpeed)
            isLongPressActive = false
            callbacks.hidePill()
        }
    }

}
